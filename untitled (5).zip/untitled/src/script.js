function register(){

    const name =
        document.getElementById("registerName")
        .value.trim();

    const username =
        document.getElementById("registerUsername")
        .value.trim();

    const password =
        document.getElementById("registerPassword")
        .value;

    const password2 =
        document.getElementById("registerPassword2")
        .value;

    hideError();


    // التحقق من البيانات
    if(!name){

        showError("⚠️ يرجى إدخال الاسم");

        return;
    }


    if(!username){

        showError("⚠️ يرجى إدخال اسم المستخدم");

        return;
    }


    if(!password){

        showError("⚠️ يرجى إدخال كلمة المرور");

        return;
    }


    if(password.length < 4){

        showError(
            "⚠️ كلمة المرور يجب أن تكون 4 أحرف على الأقل"
        );

        return;
    }


    if(password !== password2){

        showError(
            "⚠️ كلمتا المرور غير متطابقتين"
        );

        return;
    }


    const oldAccount = getAccount();


    // التأكد أن اسم المستخدم غير مستخدم
    if(
        oldAccount &&
        oldAccount.username === username
    ){

        showError(
            "❌ اسم المستخدم موجود بالفعل"
        );

        return;
    }


    // إنشاء الحساب
    const account = {

        name: name,

        username: username,

        password: password

    };


    // حفظ الحساب
    localStorage.setItem(
        "healthcareAccount",
        JSON.stringify(account)
    );


    // تسجيل الدخول تلقائياً
    localStorage.setItem(
        "healthcareLoggedIn",
        "true"
    );


    // تعيين المستخدم الحالي
    currentUser = account;


    // فتح التطبيق مباشرة
    openApp();


    // رسالة نجاح
    setTimeout(()=>{

        showMessage(
            "✅ تم إنشاء الحساب وتسجيل الدخول بنجاح"
        );

    },300);

}
